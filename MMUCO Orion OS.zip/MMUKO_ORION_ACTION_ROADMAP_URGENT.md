# MMUKO ORION Compound – URGENT NEXT STEPS (ACTION ROADMAP)
**Date:** 24 May 2026  
**Status:** Ready for decisions + execution  

---

## CRITICAL DECISIONS REQUIRED (No Further Delay)

### Decision 1: OBI Avatar Formalization
**Impact:** Affects all governance structures, decision timelines, and pre-departure planning  
**Options:**
- **A.** Single elected OBI chief (elected every 3 years; serves as head mediator + community representative)
- **B.** Rotating OBI council (all adult residents serve 6-month rotation; collective decision-making)
- **C.** Professional OBI mediator corps (trained facilitators; not elected, recruited + paid)
- **D.** Hybrid (elected coordinator + rotating advisory council)

**Recommendation:** Option C (professional + trained) ensures consistent fairness; Option B (rotating) ensures maximum community participation; choose based on whether you prioritize **expertise or democracy**.

**Once decided:**
- Draft OBI avatar charter + responsibilities
- Establish OBI recruitment/training process
- Finalize OHA consensus protocols

### Decision 2: Pre-Departure Planning Timeline
**Impact:** When should compound be ready for residents to arrive?

**Scenarios:**
- **Scenario 1:** Compound fully operational by Month 36 (3 years); Nnamdi arrives as first resident
- **Scenario 2:** Compound basics ready (MMUKO OS + security) by Month 18; community arrives in phases
- **Scenario 3:** Nnamdi departs UK immediately; oversees construction remotely; arrival timed to major phases

**Questions to resolve:**
- Is this an exodus (Nnamdi leaves, then community follows)?
- Or a gradual migration (Nnamdi establishes, invites residents over time)?
- Does OBI avatar need to be in place *before* Nnamdi arrives, or can they co-develop?

**Once decided:**
- Set construction timeline milestones
- Identify pre-departure preparation (legal residency, work permits, medical clearances)
- Plan community recruitment strategy

### Decision 3: Land Selection + Site Confirmation
**Impact:** All subsequent planning depends on exact location + surveyed boundaries

**Current status:** "Nnewi, Anambra State, Nigeria" identified; 1,000,000 m² target area defined.

**Actions required:**
1. **Identify specific property** (work with Nigerian real estate agents + surveyor)
2. **Commission Land Registry search** (verify no hidden encumbrances; confirm availability for private ownership)
3. **Verify government excision status** (confirm land is not under government acquisition)
4. **Commission preliminary survey** (establish exact boundaries, area, soil quality)

**Timeline:** Should complete within **2 months** (May–June 2026).

**Cost estimate:** ₦150,000–₦300,000 (professional surveyor fees).

**Once completed:**
- Proceed to Deed of Assignment drafting
- Engage Governor's Consent application process (6–12 months)

---

## EXECUTION ROADMAP (By Phase)

### PHASE 1: Legal Foundation (Months 1–2 | May–June 2026)

#### 1A. OBI Avatar Decision
- [ ] Review Decision 1 options (A/B/C/D above)
- [ ] Consult with community stakeholders (if any exist yet)
- [ ] Make formal decision
- [ ] Document in writing (record decision rationale)

#### 1B. Pre-Departure Timeline Decision
- [ ] Review Decision 2 scenarios
- [ ] Clarify personal readiness (health, finances, legal status)
- [ ] Align with OBI avatar choice (if OBI must pre-exist, that adds months)
- [ ] Set compound opening date (target: Month X)

#### 1C. Land Identification + Survey
- [ ] Contact Nigerian real estate agents in Nnewi
- [ ] Identify 3–5 candidate properties (1M m² target)
- [ ] Commission Land Registry searches for each
- [ ] Hire surveyor; commission preliminary surveys
- [ ] Verify excision status (government acquisition clearance)
- [ ] **Select final site** (decision gate: must choose by mid-June)

**Deliverables by end of June 2026:**
- OBI Avatar Charter (formal document)
- Pre-Departure Timeline (milestones + dates)
- Land Survey Report (final site confirmed)
- Land Registry Clearance (no encumbrances)

---

### PHASE 2: Constitutional + Legal Drafting (Months 2–4 | June–August 2026)

#### 2A. IWU Equity Act Finalization
- [ ] Complete probe algebra LaTeX formalism (P(B): S → D)
- [ ] Finalize all 625 articles (or core first 100)
- [ ] Add OBI avatar governance structure
- [ ] Draft amendments procedure
- [ ] Create simplified summary for public distribution

**Dependencies:** Decision 1 (OBI avatar choice) must be complete first.

**Deliverables:**
- IWU_EQUITY_ACT_FINAL.md (markdown)
- Probe_Algebra_Formalism_Final.tex (LaTeX)
- Constitutional Summary (1-page public version)

#### 2B. Deed of Assignment Drafting
- [ ] Hire Nigerian property lawyer (Anambra-based, familiar with Igbo land law)
- [ ] Draft initial Deed incorporating:
  - Property description (survey-based)
  - Buyer: OBINexus Computing (as Nigerian entity? Or Nnamdi individually?)
  - Governance provisions (OHA/IJI/IWU structures referenced in deed)
  - Rights + responsibilities of residents
  - Amendment procedures
- [ ] Multiple review rounds (Nigerian legal counsel + Nnamdi)
- [ ] Finalize version ready for Governor's Consent application

**Deliverables:**
- Deed_of_Assignment_DRAFT.docx (ready for formal submission)
- Legal Counsel engagement letter (proof of professional review)

#### 2C. Governor's Consent Application Prep
- [ ] Compile required documents:
  - Land Registry search
  - Survey plan
  - Proof of financial capacity (investment statement or bank letter)
  - Completed application form (state-specific)
  - ID + proof of residency (if applicable)
- [ ] Submit to Anambra State Land Bureau
- [ ] Track application status (monthly follow-up)

**Timeline:** Submission by end of August; approval expected by February 2027 (6-month typical).

**Deliverables:**
- Signed Governor's Consent application
- Proof of submission (receipt/reference number)

---

### PHASE 3: Spatial Design (Months 4–8 | August–December 2026)

#### 3A. Master Site Plan
- [ ] Engage architect + urban planner (experienced with neurodivergent-centered design)
- [ ] Produce CAD site plan showing:
  - UCHE zone (north, 200k m²)
  - EZE zone (east, 200k m²)
  - OBI zone (center, 150k m²)
  - Supporting structures (south)
  - Access roads + pathways
  - Utilities corridors (water, power, waste, communications)

**Design Standards:**
- All paths: 2m minimum width, ≤1:12 ramp slope
- All buildings: wheelchair accessible, sensory-regulated spaces
- All zones: #NoGhosting principle embedded (transparency, public access)

**Deliverables:**
- Master_Site_Plan.dwg (CAD file)
- Master_Site_Plan.pdf (printable version)
- Design rationale document (why each element is placed where)

#### 3B. Zone-by-Zone Architecture
- [ ] UCHE zone:
  - Research library + reading rooms (10k m²)
  - Archive vaults (20k m²)
  - Nsibidi center (5k m²)
  - Legislative chamber (2k m²)
  - Supporting facilities (food, rest, movement)
- [ ] EZE zone:
  - Council chambers (5k m²)
  - Office suite (10k m²)
  - Judicial mediation (3k m²)
  - MMUKO OS gateway (5k m²)
  - Supporting facilities
- [ ] OBI zone:
  - Central plaza (25k m² open)
  - Covered pavilion (10k m²)
  - Consensus chambers (8 rooms, 2k m²)
  - Mediation halls (6 rooms, 1.5k m²)
  - Food service (5k m²)
  - Supporting facilities

**Deliverables:**
- Architectural drawings (each zone)
- Accessibility audit (compliance checklist)
- Cost estimates (preliminary)

#### 3C. Infrastructure Design
- [ ] Water systems (source, treatment, distribution, waste)
- [ ] Power systems (grid + backup generators)
- [ ] Communications (libpolycall network, internal internet, emergency radio)
- [ ] Waste management (composting, recycling, hazardous waste protocols)
- [ ] Emergency response (medical clinic, ambulance routes, shelters)

**Deliverables:**
- Infrastructure schematic drawings
- Engineering specifications

---

### PHASE 4: Governance System Development (Months 6–12 | October 2026–April 2027)

#### 4A. OHA/IJI/IWU Operational Procedures
- [ ] Document OHA assembly process:
  - Convening procedures
  - Agenda-setting (who proposes? How much notice?)
  - Deliberation rules (how long? How many speakers?)
  - Voting mechanism (trilateral consensus threshold; what if split?)
  - Appeal/challenge process (how long? Who arbitrates?)
- [ ] Document IJI process (UCHE authority limits)
- [ ] Document IWU process (EZE + OBI bilateral)

**Deliverables:**
- OHA_Operations_Manual.md
- IJI_Authority_Boundaries.md
- IWU_Bilateral_Procedures.md

#### 4B. Avatar Recruitment + Training
- [ ] EZE avatar:
  - Identify candidate(s) (Nnamdi initially?)
  - Define term limits + succession planning
  - Training on governance + mediation skills
- [ ] OBI avatar (depends on Decision 1):
  - If professional corps: job descriptions, salary, hiring process
  - If elected: voting procedure, term length, removal process
  - If rotating: schedule, training, briefing materials
- [ ] UCHE avatar:
  - Define archive stewardship role
  - Training on legislative research support
  - Nsibidi scholarship/mentorship program

**Deliverables:**
- Avatar Role Descriptions
- Recruitment procedures
- Training curricula

#### 4C. Resident Charter
- [ ] Draft rights + responsibilities:
  - Participation in OHA (required? Optional?)
  - Work expectations (optional except worst case)
  - Behavioral codes (what violates #NoGhosting? How enforced?)
  - Access to facilities (everyone gets equal access?)
  - Dispute resolution (who mediates? Confidentiality?)
- [ ] Onboarding materials (welcome packet, facility tours, system training)
- [ ] Departure procedures (exit interviews, knowledge transfer, final mediation)

**Deliverables:**
- Resident_Charter.md
- Onboarding_Manual.md
- Exit_Procedures.md

---

### PHASE 5: Infrastructure Buildout (Months 9–24 | January–September 2027)

**Contingent on:** Governor's Consent approval (expected February 2027)

#### 5A. Site Preparation
- [ ] Clear site
- [ ] Grade + level
- [ ] Survey stakes for foundation
- [ ] Install temporary access road
- [ ] Environmental remediation (if needed)

#### 5B. Utilities Installation
- [ ] Water: source (well? municipal?), treatment plant, distribution network
- [ ] Power: generators (backup), grid connection (if available), solar (optional), battery storage
- [ ] Waste: septic system or connection to municipal; composting stations
- [ ] Communications: libpolycall fiber network, emergency radio, internet if available
- [ ] Drainage: stormwater management, flood prevention

#### 5C. Primary Structures (Concurrent)
- [ ] UCHE zone buildings
- [ ] EZE zone buildings
- [ ] OBI zone facilities
- [ ] Supporting structures (boot, gateway, registry)

**Timeline:** Sequential or parallel (parallel reduces schedule to 15–18 months; sequential extends to 24+ months).

---

### PHASE 6: Systems Integration + Testing (Months 21–30 | August 2027–May 2028)

#### 6A. MMUKO OS Deployment
- [ ] Install hand-gesture kiosks (biometric readers)
- [ ] Deploy central database (encrypted, backed up)
- [ ] Connect MMUKO OS boot facility to NSIGII gate
- [ ] Test authentication workflows
- [ ] Validate rights-checking (625-article verification)

#### 6B. libpolycall Network
- [ ] Lay fiber throughout compound
- [ ] Install network switches + routers
- [ ] Establish encrypted governance communication channels
- [ ] Test node-to-node communication
- [ ] Establish magnetic tape backup system

#### 6C. Data Migration
- [ ] Migrate IWU Equity Act to constitutional database
- [ ] Migrate all governance precedents + decisions (from archives)
- [ ] Establish query system (residents can search decisions)
- [ ] Test database resilience (manual backup + recovery)

#### 6D. Training + Simulation
- [ ] Train MMUKO OS operators
- [ ] Train avatar staff
- [ ] Conduct mock OHA assembly (test procedures)
- [ ] Conduct mock mediation (test justice system)
- [ ] Identify + fix issues before public opening

---

### PHASE 7: Community Activation (Months 28–36 | April–December 2028)

#### 7A. Resident Recruitment
- [ ] Public announcement (compound is operational; accepting residents)
- [ ] Application process (health screening, NSIGII verification, orientation)
- [ ] Priority groups:
  - Neurodivergent first (aligned with constitution)
  - Nnewi-based professionals (local economic benefit)
  - OBINexus supporters (alignment with mission)
- [ ] Phased intake (first residents: 100–200; scale over time)

#### 7B. System Soft-Launch
- [ ] First residents arrive (Month 28)
- [ ] MMUKO OS boot + NSIGII gate operate
- [ ] Governance systems functional (OHA, IJI, IWU)
- [ ] Mediation + justice system active
- [ ] Daily operations (food, utilities, security) active

#### 7C. Iterative Refinement
- [ ] Collect resident feedback (what's working? What needs fixing?)
- [ ] Monthly community meetings (adjust procedures based on lived experience)
- [ ] Quarterly governance reviews (check consensus procedures + decision quality)
- [ ] Seasonal adjustments (facility maintenance, accessibility updates)

#### 7D. Public Opening Ceremony
- [ ] Celebratory event (Month 36)
- [ ] Invite government officials, community leaders, media
- [ ] Showcase UCHE research, EZE governance, OBI mediation
- [ ] Announce phase 2 expansion (if planned)

---

## CRITICAL PATH (Fastest Route to Opening)

**Timeline: 36 months (May 2026 → May 2029)**

```
Phase 1 (2 mo):  Land + OBI + Pre-departure decisions    [May–Jun 2026]
Phase 2 (3 mo):  Constitutional + legal drafting         [Jun–Aug 2026]
Phase 3 (4 mo):  Spatial design                          [Aug–Dec 2026]
Phase 4 (6 mo):  Governance systems + training           [Oct 2026–Apr 2027]
Phase 5 (15 mo): Infrastructure + buildout              [Jan–Sep 2027]
Phase 6 (9 mo):  Systems integration + testing           [Aug 2027–May 2028]
Phase 7 (8 mo):  Community activation + soft-launch      [Apr–Dec 2028]
Opening Ceremony: May 2029
```

**Parallel tracks accelerate timeline:**
- Phases 2, 3, 4 can overlap (design while permits pending)
- Phase 5 components can run parallel (site prep + building construction simultaneous)
- Phase 6 can start before construction fully complete (systems testing in partially-built facilities)

**Fastest realistic timeline: 30 months (goal: January 2029 soft launch).**

---

## BLOCKERS + MITIGATIONS

| Blocker | Impact | Mitigation |
|---------|--------|-----------|
| **Governor's Consent delay** | +6 months | Start Phase 3 (design) while awaiting approval; parallel path doesn't block design |
| **Construction cost overruns** | Phase 5 incomplete | Phase funding (1/4 compound opened → revenue → fund next 1/4) |
| **OBI avatar indecision** | Governance system can't launch | Default to Option C (professional corps) if undecided by Month 2 |
| **Resident recruitment slow** | Community doesn't materialize | Flexible timeline; soft-launch with 50–100 can expand to 500+ over years |
| **MMUKO OS bugs** | Systems unavailable at launch | Parallel manual backup (paper-based records) if digital fails |
| **Community rejection of tripolar model** | Governance legitimacy at risk | Transparency (all deliberations public); mediation (address concerns) |

---

## IMMEDIATE NEXT STEPS (THIS WEEK)

### By Friday, 24 May 2026:
1. **Decide OBI avatar formalization** (Decision 1)
   - Review options A/B/C/D
   - Write down your choice + rationale
2. **Clarify pre-departure timeline** (Decision 2)
   - When should compound be ready?
   - When do you plan to arrive?
   - What personal preparation is needed?
3. **Identify land in Nnewi** (Decision 3)
   - Contact 3–5 real estate agents
   - Request property listings (1M m² target)
   - Schedule video tours (if in UK, remote viewing)

### By end of June 2026:
1. **Complete land survey** (site confirmed)
2. **Complete OBI avatar charter** (governance defined)
3. **Confirm pre-departure timeline** (public announcement possible)
4. **Engage Nigerian property lawyer** (Deed drafting begins)

---

## RESOURCES REQUIRED

### Capital Investment (Preliminary)
- **Land acquisition:** ₦50–100M (depending on location; ~$120k–$240k USD)
- **Site infrastructure (water/power/waste):** ₦200–400M (~$480k–$960k)
- **Building construction:** ₦1–2B (~$2.4M–$4.8M for all zones)
- **MMUKO OS + libpolycall deployment:** ₦100–200M (~$240k–$480k)
- **Contingency (30%):** ₦300–600M (~$720k–$1.4M)

**Total estimate: ₦1.6–3.2B (~$3.8M–$7.7M USD)**

*(Rough order of magnitude; detailed cost breakdown needed after design finalization)*

### Human Resources
- **Architecture + design:** 1 lead architect, 2 engineers, 1 urban planner (~12 months full-time)
- **Legal:** 1 Nigerian property lawyer, 1 constitutional specialist (~18 months part-time)
- **Project management:** 1 PM, 1 assistant (~full-time for 36 months)
- **Community coordination:** 1 community organizer (~starts Month 12)
- **Construction oversight:** 1 site manager + 1 QA inspector (~Months 9–24)

### Expertise Gaps (Needs Filling)
- [ ] Nigerian real estate agent (identify + vet)
- [ ] Anambra-based property lawyer (identify + engage)
- [ ] Architect with neurodivergent-first design experience (identify + contract)
- [ ] MMUKO OS engineer (likely Nnamdi; clarify availability/timeline)
- [ ] libpolycall network architect (identify + contract)

---

## SUCCESS METRICS (Phase-by-Phase)

### Phase 1 Success:
- [ ] OBI avatar decision documented
- [ ] Pre-departure timeline confirmed
- [ ] Land identified + surveyed (final site selected)
- [ ] No legal encumbrances discovered

### Phase 2 Success:
- [ ] IWU Equity Act complete (all 625+ articles)
- [ ] Probe algebra LaTeX formalism finalized
- [ ] Deed of Assignment ready for submission
- [ ] Governor's Consent application submitted

### Phase 3 Success:
- [ ] Master site plan approved (all stakeholders sign-off)
- [ ] Zone-by-zone architecture designs complete
- [ ] Accessibility audit: 100% compliance target set
- [ ] Cost estimates locked (within 10% variance)

### Phase 4 Success:
- [ ] OHA/IJI/IWU procedures documented + tested
- [ ] Avatar staff recruited + trained
- [ ] Resident charter finalized
- [ ] Mock governance session completed (no major issues)

### Phase 5 Success:
- [ ] All utilities operational
- [ ] All primary structures waterproofed + secured
- [ ] Site emergency response active
- [ ] On-time, on-budget (within 15% variance)

### Phase 6 Success:
- [ ] MMUKO OS boot tested + verified
- [ ] libpolycall network tested + verified
- [ ] All databases migrated + backed up
- [ ] Staff trained + confident

### Phase 7 Success:
- [ ] 100–200 residents onboarded + resident
- [ ] OHA assembly convened successfully (trilateral consensus achieved)
- [ ] Mediation system handled 5+ conflicts (successfully resolved)
- [ ] Public opening ceremony held
- [ ] Media coverage achieved (local + international recognition)

---

## SUCCESS VISION (Year 5: May 2031)

**Compound Status:**
- 500–1,000 neurodivergent-first residents living + thriving
- UCHE zone: Leading research institution (Nsibidi, constitutional computing, human rights verification)
- EZE zone: Functional governance (biannual OHA assemblies, consistent law-making)
- OBI zone: Conflict mediation rate 95% resolved within community (minimal external escalation)
- Replication: 2–3 other MMUKO OS compounds under construction (other African countries)

**Personal Status:**
- Nnamdi: Established in Nnewi; leading OBINexus compound operations
- Pre-departure planning: Complete; all UK affairs resolved
- Autobiography: *Blood, Sweat and Tears* published (or in final draft)
- Poetry: *Butterflies on the Battlefield* published (or performing regularly)
- YouTube: 50k+ subscribers; weekly uploads of compound governance, research, cultural content

**Constitutional Impact:**
- IWU Equity Act: Adopted by other African nations (Igbo-inspired model exported)
- Probe algebra: Published in peer-reviewed mathematics/logic journals
- NSIGII protocol: Recognized as international human rights standard
- #NoGhosting: Featured in academic literature on radical transparency + governance

---

**NEXT IMMEDIATE ACTION:**
**Schedule a focused decision session (90 minutes) to resolve Decisions 1, 2, 3.** Once these are made, all subsequent phases follow mechanically. The compound is waiting.

---

*Session prepared by Claude | In support of OBINexus Constitutional Computing | 24 May 2026*
